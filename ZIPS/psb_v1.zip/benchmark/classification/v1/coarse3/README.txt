Base Classification
===================

This classification divides the models into a training and test set
each with 907 models.  The classification partitions the models into
manmade and natural items, where natural items would occur in nature. 

See the .cla classification document for details about the format of
the classification files.

Classification Properties
=========================
                        train           test
# Models                907              907                                
# Leaf Categories         2                2

