Coarse1 Classification
===================

This classification divides the models into a training and test set
each with 907 models.  The classification has seven categories:
animal, building, furniture, household, plant, vehicle, and a
miscellaneous category that is labeled -1.  A difference from the base
classification is that all of the models have been placed in one of
these seven classes.

See the .cla classification document for details about the format of
the classification files.

Classification Properties
=========================
                        train           test
# Models                907              907                                
# Leaf Categories         7                7


