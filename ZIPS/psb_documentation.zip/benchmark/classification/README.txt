Classification
==============

Currently, a version 1 classification is provided with multiple
granularities.  Most users will start with the base classification  All
classifications are in the .cla format.  Source code is available for
parsing .cla files as well as creating overview web pages.

Please see 
http://shape.cs.princeton.edu/benchmark/documentation/classification_format.html
for a specification of .cla files.


Version 1 is the current version of the classification files.
